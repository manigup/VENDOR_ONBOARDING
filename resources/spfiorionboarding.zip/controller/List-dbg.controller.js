sap.ui.define([
    "./BaseController",
    "sap/m/MessageBox",
    "sap/m/MessageToast",
    "sap/ui/model/Filter",
    "sap/ui/core/BusyIndicator",
    "sap/ui/model/json/JSONModel"
],
    /**
     * @param {typeof sap.ui.core.mvc.Controller} Controller
     */
    function (BaseController, MessageBox, MessageToast, Filter, BusyIndicator, JSONModel) {

        "use strict";

        return BaseController.extend("sp.fiori.onboarding.controller.List", {

            onInit: function () {
                this.getRouter().attachRoutePatternMatched(this.onRouteMatched, this);
                ["createFromDateId", "createToDateId"].forEach(oDatepcker => {
                    this.byId(oDatepcker).attachBrowserEvent("keypress", evt => evt.preventDefault());
                });
            },

            onRouteMatched: function (evt) {
                if (evt.getParameter("name") !== "list") {
                    return;
                }
                 this.getView().setModel(new JSONModel([]), "FormData");
                this.getData();
            },

            getData: function () {
                BusyIndicator.show();
                setTimeout(() => {
                    //  var requestData = this.getView().getModel("request").getData();

                    // this.getView().getModel().read("/EmpRoleSet", {
                    //     success: (data) => {
                    //         var access;
                    //         for (var i = 0; i < data.results.length; i++) {
                    //             access = data.results[i].Access.toUpperCase();
                    //             if (access === "BUYER") {
                    //                 requestData.buyer = true;
                    //             } else if (access === "FINANCE") {
                    //                 requestData.finance = true;
                    //             } else if (access === "LEGAL") {
                    //                 requestData.legal = true;
                    //             } else if (access === "VALIDITY RESET") {
                    //                 requestData.reset = true;
                    //             }
                    //         }
                    //         this.getView().getModel("request").refresh(true);
                    //     },
                    //     error: () => BusyIndicator.hide()
                    // });
                    this.getView().getModel().read("/VenOnboard", {
                        success: (data) => {
                            data.results.map(item => {
                                item.StatusText = formatter.formatStatus(item.Status);
                                item.WavStatusText = formatter.formatStatus(item.WavStatus);
                                parseInt(item.Score);
                                return item;
                            });
                            var reqData = { supplychain: false, finance: false };
                            var accessdata = this.getView().getModel("AccessDetails").getData();
                            var res = this.getView().getModel("UserApiDetails").getData();
                            //var res = {};
                            //res.email = "rajeshsehgal@impauto.com";
                            reqData.supplychain = accessdata.find(item => item.email === res.email && item.Access === "SCM") ? true : false;
                            reqData.finance = accessdata.find(item => item.email === res.email && item.Access === "Finance") ? true : false;
                            reqData.supplychain = true;
                            if(reqData.supplychain){
                                reqData.appbtn = "supply";
                            }else if(reqData.finance){
                                reqData.appbtn = "finance";
                            }
                            this.getView().getModel("request").setData(reqData);
                            this.getView().getModel("request").refresh(true);
                            this.getView().getModel("DataModel").setData(data.results);
                            this.getView().getModel("DataModel").setSizeLimit(data.results.length);
                            this.getView().getModel("DataModel").refresh(true);
                            // for(var i = 0; i<data.results.length; i++){
                            // this.changevalidity(data.results[i]);
                            // }
                            BusyIndicator.hide();
                        },
                        error: () => BusyIndicator.hide()
                    });
                }, 1000);
            },

            onSearch: function (evt) {
                var sValue = evt.getParameter("query");
                if (evt.getParameter("refreshButtonPressed")) {
                    this.getData();
                } else if (sValue) {
                    this.byId("createFromDateId").setValue("");
                    this.byId("createToDateId").setValue("");
                    this.byId("vendorList").getBinding("items").filter([new Filter([
                        new Filter("Vendor", sap.ui.model.FilterOperator.Contains, sValue), // Supplier Code
                        new Filter("VendorName", sap.ui.model.FilterOperator.Contains, sValue), // Supplier Name
                        new Filter("Lifnr", sap.ui.model.FilterOperator.Contains, sValue), // Business Partner
                        new Filter("VenApprovalPending", sap.ui.model.FilterOperator.Contains, sValue), // Approval Pending
                        new Filter("StatusText", sap.ui.model.FilterOperator.Contains, sValue) // Status
                    ])]);
                } else {
                    this.byId("vendorList").getBinding("items").filter([]);
                }
            },

            onCreationDateFilter: function () {
                var fromValue = this.byId("createFromDateId").getValue(),
                    toValue = this.byId("createToDateId").getValue();
                if (fromValue && toValue) {
                    this.byId("vendorList").getBinding("items").filter([new Filter([
                        new Filter("createdAt", sap.ui.model.FilterOperator.BT, fromValue, toValue)
                    ])]);
                } else if (fromValue) {
                    this.byId("vendorList").getBinding("items").filter([new Filter([
                        new Filter("createdAt", sap.ui.model.FilterOperator.EQ, fromValue)
                    ])]);
                } else if (toValue) {
                    this.byId("vendorList").getBinding("items").filter([new Filter([
                        new Filter("createdAt", sap.ui.model.FilterOperator.LE, toValue)
                    ])]);
                } else {
                    this.byId("vendorList").getBinding("items").filter([]);
                }
                this.byId("search").setValue("");
            },

            onCreatePress: function () {
                var dialog = sap.ui.xmlfragment("sp.fiori.onboarding.fragment.Create", this);
                this.getView().addDependent(dialog);
                sap.ui.getCore().byId("createDialog").setModel(new JSONModel({}), "CreateModel");
                dialog.open();
            },

            onCreateSubmit: function () {
                if (this.validateFields()) {
                    BusyIndicator.show();
                    const payload = sap.ui.getCore().byId("createDialog").getModel("CreateModel").getData();
                    payload.Vendor = this.generateVendorNo();
                    payload.VenFrom = new Date();
                    payload.VenValidTo = this.changeDate(payload.VenFrom, 7, "add");
                    setTimeout(() => {
                        this.getView().getModel().create("/VenOnboard", payload, {
                            success: (sData) => {
                                BusyIndicator.hide();
                                console.log("VendorId", sData.VendorId)
                                MessageBox.success("Vendor creation request " + sData.Vendor + " created successfully. \n\n Also, Supplier form generated please fill to procced.", {
                                    onClose: () => {
                                        sap.ui.getCore().byId("createDialog").destroy();
                                        this.getData();
                                    }
                                });
                                this.sendEmailNotification(sData.VendorName, sData.VendorId, sData.VendorMail, sData.VenValidTo);
                            },
                            error: () => BusyIndicator.hide()
                        });
                    }, 1000);
                } else {
                    MessageBox.error("Please correct all the error's to proceed");
                }
            },

            sendEmailNotification: function (vendorName, vendorId, vendorMail, validTo) {
                let emailBody = `||Please find the link below for Vendor Assessment Form. Kindly log-in with the link to fill the form.<br><br>Form is valid till ${validTo}. Request you to fill the form and submit on time.<br><br><a href="https://impautosuppdev.launchpad.cfapps.ap10.hana.ondemand.com/da8bb600-97b5-4ae9-822d-e6aa134d8e1a.onboarding.spfiorisupplierform-0.0.1/index.html?id=${vendorId}">CLICK HERE</a>`;
                var oModel = this.getView().getModel();
                var mParameters = {
                    method: "GET",
                    urlParameters: {
                        vendorName: vendorName,
                        subject: "Supplier Form",
                        content: emailBody,
                        toAddress: vendorMail
                    },
                    success: function (oData, response) {
                        console.log("Email sent successfully.");
                    },
                    error: function (oError) {
                        console.log("Failed to send email.");
                    }
                };
                oModel.callFunction("/sendEmail", mParameters);
            },
            onFormPress: function () {
                let url = "http://localhost:4004/supplierform/webapp/index.html?id=" + this.vendorId
                /*
                const href = window.location.href;
                let url;
                if (href.includes("impautosuppdev")) {

                    url = "https://impautosuppdev.launchpad.cfapps.ap10.hana.ondemand.com/da8bb600-97b5-4ae9-822d-e6aa134d8e1a.onboarding.spfiorisupplierform-0.0.1/index.html?id=" + this.vendorId;

                } else {
                    url = "/supplierform/webapp/index.html?id=" + this.vendorId;
                }
                */
                window.open(url);
            },

            onMoreInfoPress: function (evt) {
                evt.getSource().getParent().getParent().destroy();
                this.getRouter().navTo("Form", { VendorId: this.vendorId });
            },

            onVendorPress: function (evt) {
                var data = evt.getSource().getBindingContext("DataModel").getObject();
                var requestData = this.getView().getModel("request").getData();
                this.vendor = data.Vendor;
                this.vendorId = data.VendorId;
                if (requestData.supplychain === true) {
                    data.Access = "SCM";
                } else if (requestData.finance === true) {
                    data.Access = "Finance";
                }
                var popOver = sap.ui.xmlfragment("sp.fiori.onboarding.fragment.VendorDetails", this);
                sap.ui.getCore().byId("displayPopover").setModel(new JSONModel(data), "VenModel");
                this.getView().addDependent(popOver);
                popOver.openBy(evt.getSource());
            },
            onResetValidityPress: function (evt) {
                BusyIndicator.show();
                var source = evt.getSource();
               // this.id = sap.ui.getCore().byId("displayPopover").getModel("VenModel").getProperty("/Vendor");
                var vendata = this.getView().getModel("DataModel").getData();
                var payload = {};
                for (var i = 0; i < vendata.length; i++) {
                    if (vendata[i].VendorId === this.vendorId) {
                        payload.Vendor = vendata[i].Vendor;
                        payload.VendorId = vendata[i].VendorId;
                        payload.VendorName = vendata[i].VendorName;
                        payload.VendorType = vendata[i].VendorType;
                        payload.Department = vendata[i].Department;
                        payload.Telephone = vendata[i].Telephone;
                        payload.City = vendata[i].City;
                        payload.VendorMail = vendata[i].VendorMail;
                        payload.VenFrom = new Date();;
                        payload.VenValidTo = this.changeDate(payload.VenFrom, 7, "add");
                        payload.VenTimeLeft = "";
                        payload.Status = vendata[i].Status;
                        payload.ResetValidity = "";
                        break;
                    }
                }
                setTimeout(() => {
                    this.getView().getModel().update("/VenOnboard(Vendor='" + payload.Vendor + "',VendorId=" + this.vendorId + ")", payload, {
                        success: () => {
                            BusyIndicator.hide();
                            MessageBox.success("Form validity extended for next 7 days for vendor " + this.vendor, {
                                onClose: () => {
                                    source.getParent().getParent().destroy();
                                    this.getData();
                                }
                            });
                        },
                        error: (error) => {
                            BusyIndicator.hide();
                            console.log(error);
                        }
                    });
                }, 1000);
            },

            onAttachmentPress: function (evt) {
                BusyIndicator.show();
                var source = evt.getSource();
                this.vendorId = source.getBindingContext("DataModel").getProperty("VendorId");
                setTimeout(() => {
                    this.getView().getModel().read("/Attachments", {
                        filters: [new Filter("VendorId", "EQ", this.vendorId)],
                        success: (data) => {
                            data.results.map(item => item.Url = this.getView().getModel().sServiceUrl + "/Attachments(VendorId='" + item.VendorId + "',ObjectId='" + item.ObjectId + "')/$value");
                            var popOver = sap.ui.xmlfragment("sp.fiori.onboarding.fragment.Attachment", this);
                            sap.ui.getCore().byId("attachPopover").setModel(new JSONModel(data), "AttachModel");
                            this.getView().addDependent(popOver);
                            popOver.openBy(source);
                            sap.ui.getCore().byId("attachment").setUploadUrl(this.getView().getModel().sServiceUrl + "/Attachments");
                            BusyIndicator.hide();
                        },
                        error: () => BusyIndicator.hide()
                    });
                }, 1000);
            },

            onBeforeUploadStartsAttach: function (evt) {
                BusyIndicator.show();
                evt.getParameters().addHeaderParameter(new sap.m.UploadCollectionParameter({
                    name: "slug",
                    value: this.vendorId + "/" + evt.getParameters().fileName
                }));
            },

            getAttachments: function () {
                BusyIndicator.show();
                setTimeout(() => {
                    this.getView().getModel().read("/Attachments", {
                        filters: [new Filter("VendorId", "EQ", this.vendorId)],
                        success: (data) => {
                            data.results.map(item => item.Url = this.getView().getModel().sServiceUrl + "/Attachments(VendorId='" + item.VendorId + "',ObjectId='" + item.ObjectId + "')/$value");
                            sap.ui.getCore().byId("attachPopover").setModel(new JSONModel(data), "AttachModel");
                            BusyIndicator.hide();
                        },
                        error: () => BusyIndicator.hide()
                    });
                }, 1000);
            },

            onAttachmentUploadComplete: function (evt) {
                if (evt.getParameter("files")[0].status == 201) {
                    MessageToast.show("File " + evt.getParameter("files")[0].fileName + " Attached successfully");
                    this.getAttachments();
                } else {
                    MessageBox.error(JSON.parse(evt.getParameter("files")[0].responseRaw).error.message.value);
                    BusyIndicator.show();
                }
            },

            onAttachmentDeletePress: function (evt) {
                var obj = evt.getSource().getBindingContext("AttachModel").getObject();
                MessageBox.confirm("Are you sure ?", {
                    actions: [MessageBox.Action.YES, MessageBox.Action.NO],
                    onClose: action => {
                        if (action === "YES") {
                            BusyIndicator.show();
                            setTimeout(() => {
                                this.getView().getModel().remove("/Attachments(VendorId='" + obj.VendorId + "',ObjectId='" + obj.ObjectId + "')", {
                                    success: () => {
                                        BusyIndicator.hide();
                                        MessageBox.success(obj.Filename + " deleted successfully", {
                                            onClose: () => this.getAttachments()
                                        });
                                    },
                                    error: () => BusyIndicator.hide()
                                });
                            }, 1000);
                        }
                    }
                });
            },
            changeStatus: function () {
                var vendata = this.getView().getModel("DataModel").getData();
                var formdata = this.getView().getModel("FormData").getData();
                var payload = {};
                for (var i = 0; i < vendata.length; i++) {
                    if (vendata[i].VendorId === this.vendorId) {
                        payload.Vendor = vendata[i].Vendor;
                        payload.VendorId = vendata[i].VendorId;
                        payload.VendorName = vendata[i].VendorName;
                        payload.VendorType = vendata[i].VendorType;
                        payload.Department = vendata[i].Department;
                        payload.Telephone = vendata[i].Telephone;
                        payload.City = vendata[i].City;
                        payload.VendorMail = vendata[i].VendorMail;
                        payload.VenValidTo = vendata[i].VenValidTo;
                        payload.VenFrom = vendata[i].VenFrom;
                        payload.VenTimeLeft = vendata[i].VenTimeLeft;
                        var venStatus = vendata[i].Status;
                        payload.ResetValidity = vendata[i].ResetValidity;
                        break;
                    }
                }
                var stat = "";
                var level = "";
                var pending = "";
                var appr = "0";
                if (venStatus === "SBF") {
                    stat = "SCA";
                    appr = "1"
                    level = "2";
                    pending = "Finance"
                    this.msg = "Approved by Supply Chain";
                } else if (venStatus === "SCA") {
                    stat = "ABF";
                    payload.AddressCode = formdata.AddressCode;
                    this.msg = "Approved by Finance and BP " + payload.BusinessPartnerNo + " created successfully";
                }
                payload.Status = stat;
                payload.VenLevel = level;
                payload.VenApprovalPending = pending;
                payload.VenApprove = appr;
                this.getView().getModel().update("/VenOnboard(Vendor='" + payload.Vendor + "',VendorId=" + this.vendorId + ")", payload, {
                    success: () => {
                        BusyIndicator.hide();
                        MessageBox.success(this.msg, {
                            onClose: () => this.getData()
                        });
                    },
                    error: (error) => {
                        BusyIndicator.hide();
                        console.log(error);
                    }
                });
            },
            getFormData: function () {
                var vendata = this.getView().getModel("DataModel").getData();
                var formdata = this.getView().getModel("FormData").getData();
                if(formdata.ExciseDivision === ""){
                    formdata.ExciseDivision = "-";
                }
                if(formdata.ExciseBankAcc === ""){
                    formdata.ExciseBankAcc = "-";
                }
                if(formdata.STRatePerc === ""){
                    formdata.STRatePerc = "0";
                }
                if(formdata.JWRWCost === ""){
                    formdata.JWRWCost = "0";
                }
                if(formdata.ExciseRange === ""){
                    formdata.ExciseRange = "0";
                }
                if(formdata.ExciseBankName === ""){
                    formdata.ExciseBankName = "-";
                }
                if(formdata.STRateSurcharge === ""){
                    formdata.STRateSurcharge = "0";
                }
                if(formdata.LSTNo === ""){
                    formdata.LSTNo = "0";
                }
formdata.SupplierType = "Permanent";
formdata.UnitCode = "P01";
formdata.AddressCode = "SDC-00-01";
formdata.AccountCode = "1201AOL002A";
formdata.AccountDesc = "A-ONE LOGISTICS";
formdata.LeadTime = "";
formdata.IAIvendorCode = "";
formdata.Location= "Within State";
formdata.Designation = "General Manager";
formdata.DeliveryMode = "Road";
formdata.CustomerCat = "OEM";
formdata.ExciseDivision = "-";
formdata.ExciseBankAcc = "-";
formdata.STRatePerc = "0";
formdata.Tin = "";
formdata.Composite = "0";
formdata.CreditRating = "";
formdata.CreditRatingAgency= "";
formdata.ServiceAccType = "";
formdata.ECCNo = "";
formdata.LSTDate = "";
formdata.CSTDate = "";
formdata.ExciseNo = "";
formdata.JWRWCost = "0";
formdata.CompanyType = "";
formdata.ISOExpiryDate = "";
formdata.AddressType = "OEM";
formdata.ExciseRange= "0";
formdata.ExciseBankName = "-";
formdata.ExciseDuty = "12";
formdata.CinNo = "U29299TN2006TTC061090";
formdata.GstRegistered = "1";
formdata.GSTDate = "10/JAN/1989";
formdata.ServiceAccCode = "";
formdata.STRateSurcharge = "0";
formdata.CSTNo = "822825";
formdata.LSTNo = "0";
formdata.ExciseDate= "";
formdata.MRPPercentage = "100";
formdata.SalesPersonCode = "";
formdata.Distance = "10";
formdata.TypeOfSupplier = "";
formdata.GroupingLocation = "INNHRFBD";
formdata.GroupCode5 = "";
formdata.GroupCode7 = "";
formdata.Tax = "CST00";
formdata.GroupCode4 = "";
formdata.ITransporters = "";
formdata.GroupCode8 = "";
formdata.BankAddress= "Nehru ground Faridabad";
// formdata.ContantInformation = [{
formdata.ContactPersonName = "Mr. Rajeev Khatri";
formdata.ContactPersonDepartment = "PURCHASING";
formdata.ContactPersonDesignation = "G.M.";
formdata.ContactPersonPhone = "9956299740";
formdata.ContactPersonMobile = "9956299740";
formdata.ContactPersonMail = "rkhatri@impauto.com";
formdata.SNo = "1";
// }]
// formdata.DocumentRequired = [{
formdata.DocCode = "38";
formdata.DocDescription= "FORM 38";
// }]
formdata.TransMode = "ADD";
formdata.CreatedBy = "Manikandan";
formdata.CreatedIP = "";
formdata.UpdatedBy = "";
                var sPath = "https://imperialauto.co:84/IAIAPI.asmx/PostSupplierMaster";
                $.ajax({
                        type: "POST",
                        contentType: "application/json",
                        url: sPath,
                        data: formdata,
                        context: this,
                        success: function (data, textStatus, jqXHR) {
                           this.changeStatus();
                        }.bind(this),
                        error: function (error) {
                            MessageBox.success("BP creation failed");
                        }
                    });
            },
            onApprPress: function (evt) {
                var vendata = this.getView().getModel("DataModel").getData();
                var sPath= evt.getSource().getBindingContext("DataModel").sPath.split("/")[1];
                this.vendorId = vendata[sPath].VendorId;
                var status = vendata[sPath].Status;
                if(status === "SCA"){
                setTimeout(() => {
                    this.getView().getModel().read("/VendorForm(VendorId='" + this.vendorId + "')", {
                        success: (data) => {
                        this.getView().getModel("FormData").setData(data);
                        var accessdata = this.getView().getModel("AccessDetails").getData();
                            this.compcodecheck = accessdata.find(item => item.CompCode === data.Bukrs) ? true : false;
                            this.compcodecheck = true;
                            BusyIndicator.hide();
                            if(this.compcodecheck){
                                this.getFormData();
                            }else{
                                MessageBox.error("User does not belong to company code " + data.Bukrs + " and hence cannot approve");  
                            }
                        },
                        error: () => {
                            BusyIndicator.hide();
                        }
                    });
                }, 1000);
            }else if(status === "SBF"){
                setTimeout(() => {
                    this.getView().getModel().read("/VendorForm(VendorId='" + this.vendorId + "')", {
                        success: (data) => {
                        this.getView().getModel("FormData").setData(data);
                        var accessdata = this.getView().getModel("AccessDetails").getData();
                            this.compcodecheck = accessdata.find(item => item.CompCode === data.Bukrs) ? true : false;
                            this.compcodecheck = true;
                            BusyIndicator.hide();
                            if(this.compcodecheck){
                                this.changeStatus();
                            }else{
                                MessageBox.error("User does not belong to company code " + data.Bukrs + " and hence cannot approve");  
                            }
                        },
                        error: () => {
                            BusyIndicator.hide();
                        }
                    });
                }, 1000);
            }
                
                // var payload = {};
                // for (var i = 0; i < vendata.length; i++) {
                //     if (vendata[i].VendorId === this.vendorId) {
                //         payload.Vendor = vendata[i].Vendor;
                //         payload.VendorId = vendata[i].VendorId;
                //         payload.VendorName = vendata[i].VendorName;
                //         payload.VendorType = vendata[i].VendorType;
                //         payload.Department = vendata[i].Department;
                //         payload.Telephone = vendata[i].Telephone;
                //         payload.City = vendata[i].City;
                //         payload.VendorMail = vendata[i].VendorMail;
                //         payload.VenValidTo = vendata[i].VenValidTo;
                //         payload.VenFrom = vendata[i].VenFrom;
                //         payload.VenTimeLeft = vendata[i].VenTimeLeft;
                //         var venStatus = vendata[i].Status;
                //         payload.ResetValidity = vendata[i].ResetValidity;
                //         break;
                //     }
                // }
                // var stat = "";
                // var level = "";
                // var pending = "";
                // var appr = "0";
                // if (venStatus === "SBF") {
                //     stat = "SCA";
                //     appr = "1"
                //     level = "2";
                //     pending = "Finance"
                //     this.msg = "Approved by Supply Chain";
                // } else if (venStatus === "SCA") {
                //     stat = "ABF";
                //     this.msg = "Approved by Finance and BP created successfully";
                //     payload.BusinessPartnerNo = "90789S";
                // }
                // payload.Status = stat;
                // payload.VenLevel = level;
                // payload.VenApprovalPending = pending;
                // payload.VenApprove = appr;
                // this.getView().getModel().update("/VenOnboard(Vendor='" + payload.Vendor + "',VendorId=" + this.vendorId + ")", payload, {
                //     success: () => {
                //         BusyIndicator.hide();
                //         MessageBox.success(this.msg, {
                //             onClose: () => this.getData()
                //         });
                //     },
                //     error: (error) => {
                //         BusyIndicator.hide();
                //         console.log(error);
                //     }
                // });
            },
            onRejPress: function (evt) {
                var vendata = this.getView().getModel("DataModel").getData();
                var sPath= evt.getSource().getBindingContext("DataModel").sPath.split("/")[1];
                this.vendorId = vendata[sPath].VendorId;
                var payload = {};
                for (var i = 0; i < vendata.length; i++) {
                    if (vendata[i].VendorId === this.vendorId) {
                        payload.Vendor = vendata[i].Vendor;
                        payload.VendorId = vendata[i].VendorId;
                        payload.VendorName = vendata[i].VendorName;
                        payload.VendorType = vendata[i].VendorType;
                        payload.Department = vendata[i].Department;
                        payload.Telephone = vendata[i].Telephone;
                        payload.City = vendata[i].City;
                        payload.VendorMail = vendata[i].VendorMail;
                        payload.VenValidTo = vendata[i].VenValidTo;
                        payload.VenFrom = vendata[i].VenFrom;
                        payload.VenTimeLeft = vendata[i].VenTimeLeft;
                        var venStatus = vendata[i].Status;
                        payload.ResetValidity = vendata[i].ResetValidity;
                        break;
                    }
                }
                var stat = "";
                var level = "";
                var pending = "";
                var appr = "0";
                if (venStatus === "SBF") {
                    stat = "SCR";
                    this.msg = "Rejected successfully by Supply Chain";
                } else if (venStatus === "SCA") {
                    stat = "RBF";
                    this.msg = "Rejected successfully by Finance";
                }
                payload.Status = stat;
                payload.VenLevel = level;
                payload.VenApprovalPending = pending;
                payload.VenApprove = appr;
                this.getView().getModel().update("/VenOnboard(Vendor='" + payload.Vendor + "',VendorId=" + this.vendorId + ")", payload, {
                    success: () => {
                        
                        MessageBox.success(this.msg, {
                            onClose: () => this.getData()
                        });
                    },
                    error: (error) => {
                        BusyIndicator.hide();
                        console.log(error);
                    }
                });
            },
            // changevalidity: function (venItem) {
            //     var payload = venItem;
            //     var today = new Date();
            //     var expirationDate = new Date(venItem.VenValidTo);

            //     if (today >= expirationDate) {
            //     payload.ResetValidity = "X";
            //     this.getView().getModel().update("/VenOnboard(Vendor='" + payload.Vendor + "',VendorId=" + payload.VendorId + ")", payload, {
            //         success: () => {
            //              return;
            //         },
            //         error: (error) => {
            //             BusyIndicator.hide();
            //             console.log(error);
            //         }
            //     });
            // }else{
            //     return;
            // }
            
            // }
            
        });
    });
