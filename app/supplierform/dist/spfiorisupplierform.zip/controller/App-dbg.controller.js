sap.ui.define(
    [
        "sap/ui/core/mvc/Controller"
    ],
    function(BaseController) {
      "use strict";
  
      return BaseController.extend("sp.fiori.supplierform.controller.App", {
        onInit() {
        }
      });
    }
  );
  